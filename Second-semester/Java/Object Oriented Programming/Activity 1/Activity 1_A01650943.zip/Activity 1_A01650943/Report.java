public class Report{
    public double time60mph, maxSpeed;
    public boolean autopilotWorking;
}