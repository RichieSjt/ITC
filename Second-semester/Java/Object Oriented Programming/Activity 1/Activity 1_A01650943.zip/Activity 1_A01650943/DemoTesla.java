public class DemoTesla {
    public static void main(String[] args) {
        Vehicle v1 = new Vehicle();

        v1.model = "Fire Tesla";
        v1.color = "Interstellar Red";
        v1.tireSize = "40 in";
        v1.torque = "150 N/m";
        v1.autopilot = true;

        Report r1 = new Report();
        r1.time60mph = 0.5;
        r1.autopilotWorking = true;
        r1.maxSpeed = 300;

        Vehicle v2 = new Vehicle();

        v2.model = "Quasar Tesla"; 
        v2.color = "Blue space dust";
        v2.tireSize = "28 in";
        v2.torque = "80 N/m";
        v2.autopilot = true;

        Report r2 = new Report();

        r2.time60mph = 1.2;
        r2.autopilotWorking = false;
        r2.maxSpeed = 180;

        v1.setReport(r1);
        v2.setReport(r2);

        String result1 = v1.checkup() == true ? "Vehicle 1 is in good conditions" : "Vehicle 1 needs to be repaired";
        System.out.println(result1);

        String result2 = v2.checkup() == true ? "Vehicle 2 is in good conditions" : "Vehicle 2 needs to be repaired";
        System.out.println(result2);
    }
}